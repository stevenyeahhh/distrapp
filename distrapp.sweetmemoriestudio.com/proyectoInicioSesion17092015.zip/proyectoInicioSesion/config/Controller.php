<?php

	abstract class Controller{

		protected $view;

		abstract public function index();

		public function __construct(){

			$this->view=new View (Singleton::getInstance()->r->getController());



			session_start();
		}

		public function loadModel($model){

			$model=$model.'Model';

			//echo $controllerPath=ROOT.'models'.DS.$model.'.php';

			if(is_readable($controllerPath=ROOT.'models'.DS.$model.'.php')){

				include_once $controllerPath=ROOT.'models'.DS.$model.'.php';

				return new $model;

			}

			



		}

		public function sesionIniciada(){

			return isset($_SESSION['IDENTIFICADOR']);

		}
		public function getSesionVar($name){
			return $_SESSION[$name]; 
		}
		public function  cerrarSesion(){
			session_destroy();
		}

	}



?>