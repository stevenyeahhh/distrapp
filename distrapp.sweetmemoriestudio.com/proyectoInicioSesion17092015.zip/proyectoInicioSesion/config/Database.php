<?php 
	
	class Database extends PDO
	{
		
		function __construct()
		{
			parent::__construct('mysql:host=mysql.hostinger.co;dbname=u524098790_users',
			    'u524098790_root',
			    'yLt7yRuHOk',array(
			    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
			));
		}
		function selectQuery($table,$columns,$where){

			$where=trim($where)==""?"":" WHERE $where";
//			echo "SELECT $columns FROM $table $where";
			return parent::query("SELECT $columns FROM $table $where");
		}
		function insertQuery($table,$columns,$values){
		//echo "$table, $columns, $values";

			//echo "INSERT INTO $table ($columns) VALUES ($values)";
			return parent::query("INSERT INTO $table ($columns) VALUES ($values)");

		}
		function updateQuery($table,$columnValues,$where){
			//echo "UPDATE $table SET $columnValues WHERE $where";
			return parent::query("UPDATE $table SET $columnValues WHERE $where");
		}
	}
?>