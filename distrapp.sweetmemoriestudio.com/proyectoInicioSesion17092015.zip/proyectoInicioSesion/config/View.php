<?php
	class View{
		private $controller;
		private $title;
		private $jsScripts;
		private $viewPath;
		private $controllerPath;
		private $error;
		private $params;
		private $mensaje;
		public function __construct($controller){
			$this->controller=strtolower($controller);
			$this->jsScripts=array();
		} 
		public function setTitle($title){
			$this->title=$title;
		}

		public function setMensaje($mensaje){
			$this->mensaje=$mensaje;
		}

		public function setError($error){
			$this->error=$error;
		}
		public function renderize($view){
			
			$this->controllerPath=BASE.DS.$this->controller.DS;
			$this->viewPath=BASE.'views'.DS.$this->controller.DS;
			$menu=array();
			$paramsPath=ROOT.'views/layout/'.DEFAULT_LAYOUT.'/';
			$layout=array(
					'css'=>$paramsPath.'css/',
					'img'=>$paramsPath.'img/',
					'js'=>$paramsPath.'js/'
				);

			$viewPath=ROOT.'views'.DS.$this->controller.DS.$view.'.phtml';
			//echo $viewPath;
			if(is_readable($viewPath)){
				include_once ROOT.'views'.DS.'layout'.DS.'header.phtml';
				include_once $viewPath;
				include_once ROOT.'views'.DS.'layout'.DS.'footer.phtml';
			}
		}
		public function setJs(array $js){
			$this->jsScripts=$js;
		}
		public function setParams($param,$name){
			$this->params[$name]=$param;
		}
		
	}
?>