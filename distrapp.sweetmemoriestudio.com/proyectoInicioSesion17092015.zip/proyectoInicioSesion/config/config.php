<?php 
	define('DS',DIRECTORY_SEPARATOR);
	define('DEFAULT_CONTROLLER', 'index');
	define('ROOT', $_SERVER['DOCUMENT_ROOT'].DS.'proyectoInicioSesion'.DS);
	define('DEFAULT_LAYOUT', 'default');
	//define('BASE', 'http://localhost/proyectoInicioSesion/');
	define('BASE', 'http://'.$_SERVER['SERVER_NAME'].'/proyectoInicioSesion/');
?>