<?php
	class PreguntasController extends Controller{
		private $p;
		public function __construct(){
			parent::__construct();
			$this->p=$this->loadModel("Preguntas");
		}

		public function index(){
			
		}
		public function crearPreguntas(){

			if($_POST){
				extract($_POST);
				$this->p->setDescripcion($descripcion);
				if($this->p->insertPreguntas()){
					$this->view->setMensaje("Insertó correctamente");
				}
				else{
					$this->view->setError("Ocurrió un error");
				}
			}
			else{
				
				
			}
			$this->view->setParams($this->p->selectPreguntas(),"PREGUNTAS");
			$this->view->setTitle("Crear Preguntas");
			$this->view->renderize("crearPreguntas");
			
			
		}
		public function responder(){
			if(!$this->sesionIniciada()){

				header("Location:".BASE.DS.'index'.DS);

			}
			$usuario=$this->getSesionVar('IDENTIFICADOR');

			if($_POST){
				$respuesta=$this->loadModel("Respuestas");

				$respuesta->setidUsuario($usuario);

				$controlador=true;
				foreach($_POST  as $key=>$value){
					if(substr($key,0,8)=="pregunta"){
						$idPregunta=substr($key,8,strlen($key));
						if(trim($value)!=""){
							$respuesta->setIdPreguntas($idPregunta);
							$respuesta->setRespuesta($value);
							if(!$respuesta->insertPreguntas()){
								$controlador=false;						
							}
						}
					}
				}
				if($controlador){
					$this->view->setMensaje("Insertó correctamente");
				}
				else{
					$this->view->setError("Ocurrio un error");
				}

			}else{

			}
			$this->view->setParams($this->p->selectRespuestas($usuario),"PREGUNTAS");
			$this->view->setTitle("Crear Preguntas");
			$this->view->renderize("responder");


			
		}

	}
?>