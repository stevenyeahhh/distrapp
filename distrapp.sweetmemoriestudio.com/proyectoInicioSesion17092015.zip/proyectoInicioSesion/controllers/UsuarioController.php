<?php

	class UsuarioController extends Controller{

		private $u;

		public function __construct(){

			

			parent::__construct();

			if(!$this->sesionIniciada()){

				header("Location:".BASE.DS.'index'.DS);

			}

			$this->u = $this->loadModel("Usuario");

			$this->view->setParams($this->u->getUsuario($this->getSesionVar('IDENTIFICADOR')),'USER_DATA'); 

		}

		public function index(){

			$this->view->setJs(array('validate'));

			$this->view->renderize('herramientas');

		}

		public function consultar(){

			$this->view->setTitle("Consulta de datos");

			$this->view->renderize('index');

			

		}

		public function cerrarSesion(){

			$this->u->cerrarSesion();

			header("Location:".BASE.DS.'index'.DS.'index');

		}

		public function modificar(){

			$this->view->setJs(array('validate'));

			if($_POST){

				

				$controlador=false;

				extract($_POST);

				$this->u->setNombre($nombre);

				$this->u->setApellido($apellido);

				$this->u->setId($id);

				$this->u->setContrasena($contrasena);

				$this->u->setTelefono($telefono);

				$this->u->setIdentificador($this->getSesionVar('IDENTIFICADOR'));

				if($this->u->validar(1)){

					if($this->u->actualizar()){

						$controlador=true;

					}					

				}

				header("Location:".BASE.DS.'usuario'.DS.'modificar');				

			}

			else{

				$this->view->setTitle("Modificar");

				$this->view->renderize('modificar');	

			}

			

		}

		public function eliminar(){

			$this->u->setIdentificador($this->getSesionVar('IDENTIFICADOR'));

			$this->u->inhabilitar();

			$this->u->cerrarSesion();

			header("Location:".BASE.DS.'index'.DS.'index');

		}
		public function consultarUsuarios(){
			if($this->getSesionVar('ID_ROL')!=2){
				echo "NO TIENE ACCESO A ESTA OPCIÓN";
			}else{
				$this->view->setParams($this->u->getUsuarios(),'ALL_USERS');
				$this->view->setTitle("CONSULTAR TODOS LOS USUARIOS");
				$this->view->setJs(array("switch"));
				$this->view->renderize("consultarUsuarios");
			}
		}

		public function cambiarEstadoUsuario(){
			if($_POST){
				extract($_POST);
				if(is_numeric($usuario) && is_numeric($estado)){					
					die(($this->u->cambiarEstadoUsuario($usuario,$estado)?"Éxito al ".(($estado)?"activar":"desactivar")."  el usuario '$usuario'":"No se pudo actualizar el usuario"));
				}
			}
		}

		public function preguntas(){
			$this->view->setTitle("Preguntas de seguridad");
			$this->view->renderize("preguntas");
		}
	}



?>