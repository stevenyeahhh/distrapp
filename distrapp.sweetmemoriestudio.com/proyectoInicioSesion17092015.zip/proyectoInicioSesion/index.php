<?php
include 'config/config.php';

//include 'localhost\proyectoInicioSesion\controllers\IndexController.php';
function __autoload($resource){
	if(is_readable(ROOT.'config'.DS.$resource.'.php')){
		include ROOT.'config'.DS.$resource.'.php';
	}
}
try {
	$r=new Request();
	$db=new Database();
	$singleton=Singleton::getInstance();
	$singleton->db=$db;
	$singleton->r=$r;
	new Boot($singleton->r);


} catch (Exception $e) {
	var_dump($e);	
}
	


?>