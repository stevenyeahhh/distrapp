<?php 

	class UsuarioModel extends Model{

		private $id;

		private $nombre;

		private $apellido;

		private $contrasena;

		private $telefono;

		private $identificador;

		private $estado;
		
		private $idRol;

		private $errores;

		private $campos;	





		public function __construct	(){

			$errores=array();

			$this->campos="nombre,apellido,id,contrasena,telefono";



		}

		public function setNombre($nombre){

			$this->nombre=$nombre;

		}

		public function setApellido($apellido){

			$this->apellido=$apellido;

		}

		public function setId($id){

			$this->id=$id;

		}

		public function setContrasena($contrasena){

			$this->contrasena=$contrasena;

		}

		public function setTelefono($telefono){

			$this->telefono=$telefono;

		}

		public function validar($tipo){

			if($tipo==1){

				$controlador=true;

				if(empty(trim($this->nombre))){

					$this->errores['nombre']="Campo vacio";

					$controlador=false;

				}

				if(empty(trim($this->apellido))){

					$this->errores['apellido']="Campo vacio";

					$controlador=false;

				}

				if(empty(trim($this->id))){

					$this->errores['id']="Campo vacio";

					$controlador=false;

				}

				if(empty(trim($this->contrasena))){

					$this->errores['contrasena']="Campo vacio";

					$controlador=false;

				}

				if(empty(trim($this->telefono))){

					$this->errores['telefono']="Campo vacio";

					$controlador=false;

				}	

			}

			elseif($tipo==2){

				$controlador=true;

				if(empty(trim($this->id))){

					$this->errores['id']="Campo vacio";

					$controlador=false;

				}

				if(empty(trim($this->contrasena))){

					$this->errores['contrasena']="Campo vacio";

					$controlador=false;

				}

			}

			

			return $controlador;

		}



		public function  getSQL($var){

			return $var==1?"'$this->nombre','$this->apellido','$this->id','$this->contrasena','$this->telefono'":

							"nombre='$this->nombre',apellido='$this->apellido',id='$this->id',contrasena='$this->contrasena',telefono ='$this->telefono'";

		}

		public function insertar(){

			return Singleton::getInstance()->db->insertQuery("users", $this->campos,self::getSQL(1));

		}

		public function getCampos(){

			return $this->campos;

		}

		public function getErrores(){

			return $this->errores;

		}

		public function setIdentificador($identificador){

			$this->identificador=$identificador;

		}

		public function iniciarSesion(){

			$usuario= Singleton::getInstance()->db->selectQuery("users","*","ID='$this->id' AND CONTRASENA='$this->contrasena' AND ESTADO='1'");

			
			
			
			$data=$usuario->fetch();

			
			$this->identificador=$data['IDENTIFICADOR'];



			$_SESSION['NOMBRE']=$data['NOMBRE'];

			$_SESSION['APELLIDO']=$data['APELLIDO'];

			$_SESSION['ID']=$data['ID'];

			$_SESSION['IDENTIFICADOR']=$data['IDENTIFICADOR'];

			$_SESSION['ID_ROL']=$data['ID_ROL'];


			
			return $usuario->rowCount();



		
		}

		

		public static function cerrarSesion(){

			session_destroy();

		}

		public static function getUsuario($id){

			return Singleton::getInstance()->db->selectQuery("users","*","identificador='$id'")->fetch(PDO::FETCH_ASSOC);

		}

		public static function getSesion($variable){

			return $_SESSION[$variable];

		}

		public function actualizar(){

			return Singleton::getInstance()->db->updateQuery("users", self::getSQL(2), " identificador ='$this->identificador'");

		}

		public function inhabilitar(){

			return Singleton::getInstance()->db->updateQuery("users", "estado ='0'", " identificador ='$this->identificador'");	

		}

		public function getUsuarios(){
			return Singleton::getInstance()->db->selectQuery("users","*"," ID_ROL!='2'")->fetchAll(PDO::FETCH_ASSOC);
		}		
		public static function cambiarEstadoUsuario($idusuario,$estado){

			return Singleton::getInstance()->db->updateQuery("users", "estado ='$estado'", " identificador ='$idusuario'")->rowCount();

		}

		public static function getUsuarioById($id){

			return Singleton::getInstance()->db->selectQuery("users","*","ID='$id'")->fetch(PDO::FETCH_ASSOC);

		}
		public static function cambiarContrasena($identificador,$contrasena){
			return Singleton::getInstance()->db->updateQuery("users", "contrasena='$contrasena'", " identificador='$identificador'")->rowCount();
		}
	}

?>